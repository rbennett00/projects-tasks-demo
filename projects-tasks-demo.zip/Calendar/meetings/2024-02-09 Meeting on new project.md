---
meeting_date: 2024-02-09
meeting_topic: 2024-02-09 Meeting on new project
attendees:
  - "[[Anna Winter]]"
  - "[[John Doe]]"
project: "[[Some new project]]"
tags: 
type: meeting
created: 2024-02-09
template_version: "1.0"
in:
  - "[[Meetings]]"
---

# Meeting Goal


# Notes


# Actions

