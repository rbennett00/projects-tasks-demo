---
up:
  - "[[Efforts]]"
project: Launch new website
created: 2024-02-09
start_date: 2024-02-09
project_status: on
area: Marketing
dependencies: 
product: 
stakeholders:
  - "[[Bill Smith]]"
project_team:
  - "[[Anna Winter]]"
  - "[[John Doe]]"
  - "[[Simone Sez]]"
tags: 
rank: 
type: project
template_version: "1.1"
---
# Project Goals
- x
- y
- z
# Notes

---

> [!multi-column]
>> [!todo]+ Tasks
>> ``` tasks
>> not done
>> description includes 📋[[Launch new website]]
>> sort by due
>> group by priority
>> short mode
>>```
>
>>[!hint]+ Meetings
>>  ``` dataview
>>  list
>>  from "Calendar/meetings"
>>  where contains(project, this.file.link)
>>  sort meeting_date desc
>>  ```
>
>> [!summary]+ Documents
>>  -
>>  -

---


Back to `= this.up`