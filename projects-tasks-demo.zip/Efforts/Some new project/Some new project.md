---
up: "[[Efforts]]"
project: Some new project
created: 2024-02-09
start_date: 2024-02-09
project_status: on
area: Home
dependencies: 
product: 
stakeholders:
project_team:
tags: 
rank:
type: project
template_version: "1.1"
---
# Project Goals
- x
- y
- z
# Notes

---

> [!multi-column]
>> [!todo]+ Tasks
>> ``` tasks
>> not done
>> description includes 📋[[Some new project]]
>> sort by due
>> group by priority
>> short mode
>>```
>
>>[!hint]+ Meetings
>>  ``` dataview
>>  list
>>  from "Calendar/meetings"
>>  where contains(project, [[Some new project]])
>>  sort meeting_date desc
>>  ```
>
>> [!summary]+ Documents
>>  -
>>  -

---
Back to `= this.up`