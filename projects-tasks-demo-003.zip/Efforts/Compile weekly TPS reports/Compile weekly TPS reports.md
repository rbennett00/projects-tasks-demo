---
up: "[[Efforts]]"
project: Compile weekly TPS reports
created: 2024-02-10
start_date: 2024-02-10
project_status: ♻️ Ongoing
area: Sales
dependencies: 
product: 
stakeholders:
project_team:
tags: 
rank:
type: project
template_version: "1.1"
---
# Project Goals
- x
- y
- z
# Notes

---

> [!multi-column]
>> [!todo]+ Tasks
>> ``` tasks
>> not done
>> description includes 📋[[Compile weekly TPS reports]]
>> sort by due
>> group by priority
>> short mode
>>```
>
>>[!hint]+ Meetings
>>  ``` dataview
>>  list
>>  from "Calendar/Meetings"
>>  where contains(project, this.file.link)
>>  sort meeting_date desc
>>  ```
>
>> [!summary]+ Documents
>>  -
>>  -

---
Back to `= this.up`