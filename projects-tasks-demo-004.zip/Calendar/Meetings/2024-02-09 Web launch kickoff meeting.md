---
meeting_date: 2024-02-09
meeting_topic: 2024-02-09 Web launch kickoff meeting
attendees:
  - "[[John Doe]]"
  - "[[Simone Sez]]"
  - "[[Anna Winter]]"
  - "[[Bill Smith]]"
project: "[[Launch new website]]"
tags: 
type: meeting
created: 2024-02-09
template_version: "1.0"
in:
  - "[[Meetings]]"
---

# Meeting Goal


# Notes


# Actions
- [ ] Prepare RFP for hosting providers 📋[[Launch new website]] 📅 2024-02-14
